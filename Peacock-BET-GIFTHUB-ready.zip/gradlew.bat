@echo off
setlocal
set "GRADLE_VERSION=8.7"
set "DIST=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin"
set "ZIP=%USERPROFILE%\.gradle\gradle-%GRADLE_VERSION%-bin.zip"
if exist "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" goto run
if not exist "%ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%DIST%'"
:run
call "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
endlocal
