# PEACOCK-BET Android Project

Android Gradle project for building the bundled HTML app.

## Build

- Java 17 recommended
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- compileSdk 35
- targetSdk 35
- minSdk 23

On systems with Gradle installed: `gradle assembleDebug`

If the host supports the included bootstrap wrapper: `./gradlew assembleDebug`

The generated debug APK is:
`app/build/outputs/apk/debug/app-debug.apk`
