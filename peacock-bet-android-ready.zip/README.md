# PEACOCK X BET Android App

This project wraps the supplied `peacock_xbet_admin_flow-16.html` in an Android WebView.

## Build on GitHub

1. Upload/commit the whole project to the repository root.
2. Open **Actions**.
3. Select **Build APK**.
4. Run the workflow.
5. Download the **Peacock-BET-APK** artifact.

The HTML uses browser localStorage for its login/customer data, and WebView DOM storage is enabled so that data can persist between app launches.
